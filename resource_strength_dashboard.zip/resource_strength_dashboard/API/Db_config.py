import os
from dotenv import load_dotenv
import pymssql
import pandas as pd
import Logic as lg
import json

load_dotenv()

DB_HOST = os.getenv("DB_HOST")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_NAME = os.getenv("DB_NAME")


def live_db():
    conn = pymssql.connect(
        user=DB_USER,
        password=DB_PASSWORD,
        host=DB_HOST,
        database=DB_NAME,
        autocommit=True,
    )
    cursor = conn.cursor()
    return conn, cursor


def db_disconnect(conn, cursor):
    cursor.close()
    conn.close()


def AuthenticateUser(username, password):
    try:
        encryptedPassword = lg.get_encrypted_code(password)
        conn, cursor = live_db()
        query = f"""
        select * from users where User_Id = '{username}' and Password = '{encryptedPassword}' and Is_Active = 1
        """
        df = pd.read_sql(query, conn)
        db_disconnect(conn, cursor)
        return len(df) > 0
    except Exception as e:
        if conn and cursor:
            db_disconnect(conn, cursor)
        print("Error in Authentication: ", e)
        return False


def getDesignation():
    try:
        q = """
        WITH UserCountCTE AS (
    SELECT 
        Designation_Id, 
        COUNT(*) AS UserCount,
        AVG(DATEDIFF(MONTH, E.joining_date, GETDATE())) AS AvgTenureMonths
    FROM users U
    JOIN Emp_Personal_Information E ON U.Employee_Id = E.Employee_Id
    WHERE U.Designation_Id IN (
        5342347, 5342422, 5343961, 5342246, 5342260,
        5343216, 5343205, 5343077, 5342897, 5342752
    ) AND U.Is_Active = 1
    GROUP BY U.Designation_Id
)
SELECT 
    AdjustedDesignation_Id, 
    Designation_Name, 
    SUM(UserCount) AS UserCount,
    CONVERT(DECIMAL(10, 2), AVG(AvgTenureMonths) / 12.0) AS AvgTenureYears
FROM (
    SELECT 
        CASE
            WHEN D.Designation_Id IN (5342246, 5342260, 5343205, 5343216) THEN 1
            WHEN D.Designation_Id IN (5342422,5343961) THEN 2
            ELSE D.Designation_Id
        END AS AdjustedDesignation_Id, 
        D.Designation_Name, 
        ISNULL(UC.UserCount, 0) AS UserCount,
        ISNULL(UC.AvgTenureMonths, 0) AS AvgTenureMonths
    FROM Designation D
    LEFT JOIN UserCountCTE UC ON D.Designation_Id = UC.Designation_Id
    WHERE ISNULL(D.Deleted, 0) = 0 AND D.Designation_Id IN (
        5342347, 5342422, 5343961, 5342246, 5342260,
        5343216, 5343205, 5343077, 5342897, 5342752
    )
) AS Subquery
GROUP BY AdjustedDesignation_Id, Designation_Name;
        """
        conn, cursor = live_db()
        df = pd.read_sql(q, conn)
        db_disconnect(conn, cursor)
        if len(df) > 0:
            df = df.to_dict(orient="records")
            return df
    except Exception as exe:
        print("Error in getDesignation", exe)
        if conn and cursor:
            db_disconnect(conn, cursor)
        return


def getMaleFemaleCount():
    try:
        q = """select count(Employee_Id) as EmployeeCount, Gender from Emp_Personal_Information epi where epi.Employee_Id in (
select Employee_Id from users u where u.Designation_Id  IN (
        5342347, 5342897, 5342752, 5343077,
        5342422, 5343961, 5342246, 5342260, 5343216, 5343205
    ) and u.Is_Active = 1) group by Gender """
        conn, cursor = live_db()
        df = pd.read_sql(q, conn)
        db_disconnect(conn, cursor)
        if len(df) > 0:
            df = df.to_dict(orient="records")
            return json.dumps(df)
    except Exception as exe:
        print("Error in getDesignation", exe)
        if conn and cursor:
            db_disconnect(conn, cursor)


def GetLocationWise():
    try:
        query = """select epi.Present_City, count(epi.Employee_Id) as EmployeeCount from Emp_Personal_Information epi 
        where epi.Is_Active = 'Y' and Department_Name = 5002 and Designation in (5342347, 5342897, 5342752, 5343077,
        5342422, 5343961, 5342246, 5342260, 5343216, 5343205) group by epi.Present_City order by EmployeeCount DESC """
        conn, cursor = live_db()
        df = pd.read_sql(query, conn)
        db_disconnect(conn, cursor)
        # print("df",df)
        cityData = []
        emp_count = []
        if len(df) > 0:
            df = df.to_dict(orient="records")
            for entry in df:
                city = entry['Present_City']
                count = entry['EmployeeCount']

                cityData.append(city)
                emp_count.append(count)
            
        return json.dumps({'cityData': cityData,'emp_count' : emp_count})
    except Exception as exe:
        print("Error in GetLocationWise", exe)
        if conn and cursor:
            db_disconnect(conn, cursor)


def GetTenureWise():
    try:
        query = """Select Designation_Name, Total_Tenure, count(Total_Tenure) Employee_Count  from (
Select Designation_Name,case  
when CAST(Tenure AS FLOAT) <1 then 'Less than 1 Year'
when CAST(Tenure AS FLOAT) >=1 and CAST(Tenure AS FLOAT)<2 then '1 Year'
when CAST(Tenure AS FLOAT) >=2 and CAST(Tenure AS FLOAT)<3 then '2 Year'
when CAST(Tenure AS FLOAT) >=3 and CAST(Tenure AS FLOAT)<4 then '3 Year'
when CAST(Tenure AS FLOAT) >=4 and CAST(Tenure AS FLOAT)<5 then '4 Year'
when CAST(Tenure AS FLOAT) >=5 and CAST(Tenure AS FLOAT)<6 then '5 Year'
ELSE '6 Plus Year' end as Total_Tenure  from  (
Select u.Employee_Id,u.User_FName+' '+u.User_LName as Employee_Name, d.Designation_Name,d.Designation_Id ,u.Created_Date as Hiring_Created_Date,
CAST((DATEDIFF(MONTH, u.Created_Date, GETDATE()) / 12) AS nvarchar(10)) 
+ '.' 
+ CAST((DATEDIFF(MONTH, u.Created_Date, GETDATE()) % 12) AS nvarchar(10)) AS Tenure
from users u
join Designation d on d.Designation_Id = u.Designation_Id and u.Department_Id in (5002)
where u.is_Active=1 and u.Designation_Id in (5342347, 5342897, 5342752, 5343077,
        5342422, 5343961, 5342246, 5342260, 5343216, 5343205) 
) as tab
) as abc
group by Designation_Name, Total_Tenure
order by Total_Tenure """
        conn, cursor = live_db()
        df = pd.read_sql(query, conn)
        combined_data = {}
        db_disconnect(conn, cursor)
        if len(df) > 0:
            df = df.to_dict(orient="records") 
        for item in df:
            designation_name = item["Designation_Name"]
            total_tenure = item["Total_Tenure"]
            employee_count = item["Employee_Count"]
            combined_data[designation_name]= {"Total_Tenure": total_tenure,"Emplyee_count" :employee_count}
        return json.dumps(combined_data)
    except Exception as e:
        if conn and cursor:
            db_disconnect(conn, cursor)
        print("Error in GetLocationWise", e)

def GetGenderWise():
    try:
        query = """select count(Employee_Id) as emp_count, Gender from Emp_Personal_Information epi where epi.Employee_Id in (

select Employee_Id from users u where u.Designation_Id  IN (

        5342347, 5342897, 5342752, 5343077,

        5342422, 5343961, 5342246, 5342260, 5343216, 5343205

    ) and u.Is_Active = 1) group by Gender"""
        conn, cursor = live_db()
        df = pd.read_sql(query, conn)
        db_disconnect(conn, cursor)
        male_emp_count = 0
        female_emp_count = 0
        if len(df) > 0:
            df = df.to_dict(orient="records")
            male_emp_count = next((entry["emp_count"] for entry in df if entry["Gender"] == "M"), 0)
            female_emp_count = next((entry["emp_count"] for entry in df if entry["Gender"] == "F"), 0)
        return json.dumps({'male_emp_count': male_emp_count,'female_emp_count' : female_emp_count})
    except Exception as e:
        if conn and cursor:
            db_disconnect(conn, cursor)
        print("Error in GetLocationWise", e)
