from flask import Flask, request, session
from functools import wraps
from flask_cors import CORS, cross_origin
from datetime import timedelta
from Logic import *
from Db_config import *
from flask_jwt_extended import JWTManager
from flask_jwt_extended import create_access_token, get_jwt_identity, jwt_required
from Logic import *
import pandas as pd
import json


app = Flask(__name__)
app.secret_key = "RCMWebAPPKey"
app.config["SECRET_KEY"] = "My-secret-key"
jwt = JWTManager(app)

CORS(app, origins="*", allowed_headers=["Content-Type", "Authorization"])


@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "username" not in session:
            return {"Error": "LoginPage"}
        return f(*args, **kwargs)

    return decorated_function


@app.route("/login", methods=["POST"])
def APIlogin():
    return login()


@app.route("/dashboard", methods=["GET"])
# @jwt_required()
def Dashboard():
    return Fetchdata()

@app.route('/tenureWise', methods=['GET'])
def tenureWise():
    result = GetTenureWise()
    if result:
        return result
    else:
        return jsonify({"error": "An error occurred"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3300, debug=True)
