import hashlib
import re
from flask import Flask, request, session
from Db_config import *
from flask_jwt_extended import create_access_token, get_jwt_identity, jwt_required


def get_encrypted_code(password):
    byte_password = password.encode("ascii")
    sha512_hash = hashlib.sha512(byte_password)
    hash_bytes = sha512_hash.digest()
    return "".join(format(byte, "02X") for byte in hash_bytes)


def validate_username(username):
    pattern = r"^[a-zA-Z0-9]+$"
    return re.match(pattern, username) is not None


def login():
    username = request.form.get("username")
    password = request.form.get("password")
    if validate_username(username):
        print(AuthenticateUser(username, password))
        if AuthenticateUser(username, password):
            access_token = create_access_token(identity=username)
            return {"access_token": access_token}
        else:
            return {"Message": False}
    else:
        return {"Message": False}


def Fetchdata():
    try:
        df = getDesignation()
        GenderCount = getMaleFemaleCount()
        LocationWise = GetLocationWise()
        TenureWise = GetTenureWise()
        GenderWiseResource = GetGenderWise()
        new_data = {
            "EmployeeData": df,
            "Genderwise": GenderCount,
            "LocationWise": LocationWise,
            "TenureWise": TenureWise,
            "GenderWiseResource": GenderWiseResource,
        }
        #print(new_data["Genderwise"])
        return new_data
    except Exception as exe:
        print("Error in Fetchdata: ", exe)
